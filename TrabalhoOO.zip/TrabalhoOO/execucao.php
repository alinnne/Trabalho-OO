<?php


echo "------------------------------------------------------\n";
echo "-                 BuscadorDeMusica.com               -\n";
echo "-                                                    -\n";
echo "- Encontre as informações das suas músicas favoritas!-\n";
echo "-                                                    -\n";
echo "-1-Cadastre Músicas.                                 -\n";
echo "-2-Listar Minhas Músicas Favoritas.                  -\n";
echo "-3-Buscar Música.                                    -\n";
echo "-4-Excluir Música                                    -\n";