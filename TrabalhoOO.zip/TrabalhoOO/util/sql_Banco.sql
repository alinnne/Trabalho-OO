
    CREATE TABLE musica(
        id int AUTO_INCREMENT NOT NULL,
        nome VARCHAR(70)NOT NULL,
        cantor VARCHAR(70),
        anoLancamento int,
        autor varchar(50),
        album varchar(50),
        favorita boolean

    );