<?php  

class Musica{ 

    private $nome;
    private $id;
    private $cantor;
    private $anoLancamento;
    private $autor;
    private $album;
    private $favorita;
}